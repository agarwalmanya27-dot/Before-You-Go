BYG - Before You Go website

HOW TO OPEN
1. Extract the BYG_Travel_Website.zip file.
2. Open the extracted folder.
3. Double-click index.html. It opens in Chrome or Edge.
4. Keep index.html, style.css, script.js and data.js together in the same folder.

WHAT IS CONNECTED
- destinations.xlsx: all 20 destination records (destination name, state, vibe, description and image path).
- places (2).xlsx: all 100 attraction records (destination ID, place name, route, description and image URL).
- The destination ID connects each attraction to the correct destination.
- Vrindavan (destination ID 1) opens by default. Select another destination under Explore Destinations.
- Select an attraction card to read its full description.

IMAGE NOTE
The destination table contains local paths such as images/Vrindavan.jpg, but the image folder itself was not included with the uploaded spreadsheets. The page therefore uses each destination's first available attraction image as its banner fallback. Attraction photos load from the image URLs stored in your places table, so internet access is needed for those photos.

Food and shopping cards are displayed as in the reference design, but the two uploaded Excel files do not contain food or shopping records yet.
